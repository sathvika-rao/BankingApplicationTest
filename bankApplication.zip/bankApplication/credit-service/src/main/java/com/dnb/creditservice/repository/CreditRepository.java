package com.dnb.creditservice.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dnb.creditservice.dto.Credit;

@Repository
public interface CreditRepository extends CrudRepository<Credit, String> {

	List<Credit> findAllByUserId(Integer userId);
	
}
