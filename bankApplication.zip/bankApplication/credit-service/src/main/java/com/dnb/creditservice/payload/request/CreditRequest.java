package com.dnb.creditservice.payload.request;

import com.dnb.creditservice.utils.CreditType;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreditRequest {
	@Enumerated(EnumType.STRING)
//	@NotBlank(message = "Credit Type must be either Loan or Credit Card")
	private CreditType creditType;
//	@NotNull(message = "User id should not be blank")
	private Integer userId;
}
