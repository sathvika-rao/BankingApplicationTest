package com.dnb.creditservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.repository.CreditRepository;

@Service
public class CreditServiceImpl implements CreditService{
	
	@Value("${api.auth}")
	private String URL;
	
	@Autowired
	CreditRepository creditRepository;

	@Override
	public Credit createCredit(Credit credit) {
		// TODO Auto-generated method stub
		return creditRepository.save(credit);
	}

	@Override
	public List<Credit> getAllCredits() {
		// TODO Auto-generated method stub
//		List<Credit> list = new ArrayList<Credit>();
//		list.forEach(
//			e -> e.setCreditStatus(true)
//		);
		return (List<Credit>) creditRepository.findAll();
	}

	@Override
	//if the returned list is null then give no applied loans/credit cards
	public List<Credit> getAllCreditsByUserId(Integer userId) {
		// TODO Auto-generated method stub
		return creditRepository.findAllByUserId(userId);
	}

	@Override
	public Optional<Credit> approveCreditStatusById(String creditId) {
		// TODO Auto-generated method stub
		return creditRepository.findById(creditId);
	}
	
	
	
}
