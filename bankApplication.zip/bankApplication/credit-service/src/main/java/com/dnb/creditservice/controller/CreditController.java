package com.dnb.creditservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.mapper.RequestToEntityMapper;
import com.dnb.creditservice.payload.request.CreditRequest;
import com.dnb.creditservice.service.CreditService;

import jakarta.validation.Valid;

@RefreshScope
@RestController
@RequestMapping("/api/credit")
public class CreditController {
	
	@Autowired
	CreditService creditService;
	
	@Autowired
	RequestToEntityMapper mapper;
	
	
	@PostMapping("/create")
	public ResponseEntity<?> createCredit( @Valid @RequestBody CreditRequest creditRequest) {
		Credit mappedCredit = mapper.getCreditEntity(creditRequest);
		Credit credit = creditService.createCredit(mappedCredit);
		return new ResponseEntity(credit, HttpStatus.CREATED);
	}
	
	@GetMapping("/allCredits")
	//if the returned list is null then give no applied loans/credit cards
		//in dashboard, consume a loan sub-component like experience and education
	public ResponseEntity<?> getAllCredits() {
		List<Credit> credits = new ArrayList<>();
		credits = creditService.getAllCredits();
		return ResponseEntity.ok(credits);
	}
	

	@GetMapping("/allCreditsByUserId/{userId}")
	//if the returned list is null then give no applied loans/credit cards
		//in dashboard, consume a loan sub-component like experience and education
	public ResponseEntity<?> getAllCreditsByUserId(@PathVariable Integer userId) {
		List<Credit> credits = new ArrayList<>();
		credits = creditService.getAllCreditsByUserId(userId);
		return ResponseEntity.ok(credits);
	}
	
	@GetMapping("/approveCreditStatus")
	public ResponseEntity<?> approveCreditStatusByUserId(@PathVariable String creditId) {
		Credit credits = creditService.approveCreditStatusById(creditId).get();
		return ResponseEntity.ok(credits);
	}
	
}
