package com.dnb.creditservice.dto;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.dnb.creditservice.utils.CreditType;
import com.dnb.creditservice.utils.CustomAccountIdGenerator;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
public class Credit {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "credit_seq") 
	@GenericGenerator(name = "credit_seq", strategy = "com.dnb.creditservice.utils.CustomAccountIdGenerator",
	parameters = {@Parameter(name =CustomAccountIdGenerator.INCREMENT_PARAM, value = "50"),
			@Parameter(name=CustomAccountIdGenerator.VALUE_PREFIX_PARAMETER, value = "cred_"),
			@Parameter(name=CustomAccountIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d")
	})
	private String creditId;
	@Enumerated(EnumType.STRING)
	private CreditType creditType;
	private boolean creditStatus = false;
	private Integer userId;
	private Integer creditLimit = 400000;
}
