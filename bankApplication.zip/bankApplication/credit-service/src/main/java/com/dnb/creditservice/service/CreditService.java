package com.dnb.creditservice.service;

import java.util.List;
import java.util.Optional;

import com.dnb.creditservice.dto.Credit;

public interface CreditService {

	public Credit createCredit(Credit credit);
	
	public List<Credit> getAllCredits();
	
	public List<Credit> getAllCreditsByUserId(Integer userId);
	
	public Optional<Credit> approveCreditStatusById(String creditId);
	
}
