package com.dnb.creditservice.utils;

public enum CreditType {
	LOAN,
	CREDITCARD
}
