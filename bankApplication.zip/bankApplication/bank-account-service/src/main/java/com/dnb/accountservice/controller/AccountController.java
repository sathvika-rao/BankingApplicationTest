package com.dnb.accountservice.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientFundsException;
import com.dnb.accountservice.mapper.RequestToEntityMapper;
import com.dnb.accountservice.payload.request.AccountRequest;
import com.dnb.accountservice.service.AccountService;
import com.dnb.accountservice.utils.Amount;

import jakarta.validation.Valid;

@RefreshScope
@RestController
@RequestMapping("/api/account")
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	RequestToEntityMapper mapper;
	
	
	@PostMapping("/create") //@RequestMapping + post method - from spring 4.3.x
	public ResponseEntity<?> createAccount( @Valid 
			@RequestBody AccountRequest account) throws IdNotFoundException {
		//return ResponseEntity.ok(mapper.getAccountEntity(account));
		System.out.println("checking");
		Account acc = mapper.getAccountEntity(account);
		
		try {
			Account account2 = accountService.createAccount(acc);
			return new ResponseEntity(account2, HttpStatus.CREATED);
			
		} catch (IdNotFoundException e) {
			// TODO Auto-generated catch block
			throw new IdNotFoundException(e.getMessage());
		}
	}
	
	
	@GetMapping("/getAccount/{accountId}")// should help us get specific account details
	public ResponseEntity<?> getAccountById(@PathVariable("accountId") String accountId) throws IdNotFoundException {
		java.util.Optional<Account> optional = accountService.getAccountById(accountId);
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new IdNotFoundException("invalid id");
		}
	}
	
	
	@GetMapping("/allAccounts")
	public ResponseEntity<?> getAllAccounts() {
		List<Account> accounts = new ArrayList<>();
		accounts = accountService.getAllAccounts();
		return ResponseEntity.ok(accounts);
		
	}
	
	
	@DeleteMapping("delete/{accountId}")
	public ResponseEntity<?> deleteAccountById(@PathVariable("accountId") String accountId) throws IdNotFoundException {
		if(accountService.deleteAccountById(accountId)) {
			return ResponseEntity.noContent().build();
		}
		else
			throw new IdNotFoundException("id not found");
			
	}
	
	@PutMapping("withdrawal/{accountId}")
	public ResponseEntity<?> withdrawMoney(@PathVariable String accountId, @RequestBody Amount amount) throws InsufficientFundsException, IdNotFoundException {
		Account account = accountService.withdrawMoney(accountId, amount);
		return new ResponseEntity(account, HttpStatus.ACCEPTED);
	}
	
	@PutMapping("deposit/{accountId}")
	public ResponseEntity<?> depositMoney(@PathVariable String accountId, @RequestBody Amount amount) throws IdNotFoundException {
		Account account = accountService.depositMoney(accountId, amount);
		return new ResponseEntity(account, HttpStatus.ACCEPTED);
	}
	
	@PutMapping("suspend/{accountId}")
	public ResponseEntity<?> suspendAccount() {
		Account account = accountService.suspendAccount();
		return new ResponseEntity(account, HttpStatus.ACCEPTED);
	}
	
	
	
}
