package com.dnb.accountservice.repo;

import org.springframework.data.repository.CrudRepository;

public interface CreditRepository extends CrudRepository<Credit, String> {

}
