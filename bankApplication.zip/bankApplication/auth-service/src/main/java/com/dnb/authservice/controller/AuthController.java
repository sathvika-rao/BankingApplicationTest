package com.dnb.authservice.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.authservice.exception.RefreshTokenException;
import com.dnb.authservice.exception.RoleException;
import com.dnb.authservice.exception.UserNotFoundException;
import com.dnb.authservice.jwt.JwtUtils;
import com.dnb.authservice.model.ERole;
import com.dnb.authservice.model.RefreshToken;
import com.dnb.authservice.model.Role;
import com.dnb.authservice.model.User;
import com.dnb.authservice.payload.request.LoginRequest;
import com.dnb.authservice.payload.request.SignUpRequest;
import com.dnb.authservice.payload.request.TokenRefreshRequest;
import com.dnb.authservice.payload.response.JWTResponse;
import com.dnb.authservice.payload.response.MessageResponse;
import com.dnb.authservice.payload.response.TokenRefreshResponse;
import com.dnb.authservice.security.CustomUserDetails;
import com.dnb.authservice.service.RefreshTokenService;
import com.dnb.authservice.service.RoleService;
import com.dnb.authservice.service.UserService;

import jakarta.validation.Valid;
//import com.microservice.authservice.exception.RefreshTokenException;
//import com.microservice.authservice.exception.RoleException;
//import com.microservice.authservice.jwt.JwtUtils;
//import com.microservice.authservice.model.ERole;
//import com.microservice.authservice.model.RefreshToken;
//import com.microservice.authservice.model.Role;
//import com.microservice.authservice.model.User;
//import com.microservice.authservice.payload.request.LoginRequest;
//import com.microservice.authservice.payload.request.SignUpRequest;
//import com.microservice.authservice.payload.request.TokenRefreshRequest;
//import com.microservice.authservice.payload.response.JWTResponse;
//import com.microservice.authservice.payload.response.MessageResponse;
//import com.microservice.authservice.payload.response.TokenRefreshResponse;
//import com.microservice.authservice.security.CustomUserDetails;
//import com.microservice.authservice.service.RefreshTokenService;
//import com.microservice.authservice.service.RoleService;
//import com.microservice.authservice.service.UserService;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/authenticate")
@RequiredArgsConstructor
public class AuthController {

	private final UserService userService;

	private final RoleService roleService;

	private final RefreshTokenService refreshTokenService;

	private final AuthenticationManager authenticationManager;

	private final PasswordEncoder encoder;

	private final JwtUtils jwtUtils;

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {

		String username = signUpRequest.getUsername();
		String email = signUpRequest.getEmail();
		String password = signUpRequest.getPassword();
		Set<String> strRoles = signUpRequest.getRoles();
		Set<Role> roles = new HashSet<>();

		if (userService.existsByUsername(username)) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Username is already taken!"));
		}

		if (userService.existsByEmail(email)) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Email is already taken!"));
		}

		User user = new User();
		user.setEmail(email);
		user.setUsername(username);
		user.setPassword(encoder.encode(password));

		if (strRoles != null) {
			strRoles.forEach(role -> {
				switch (role) {
				case "ROLE_ADMIN":
					Role adminRole = null;

					if (roleService.findByName(ERole.ROLE_ADMIN).isEmpty()) {
						adminRole = new Role(ERole.ROLE_ADMIN);
					} else {
						adminRole = roleService.findByName(ERole.ROLE_ADMIN)
								.orElseThrow(() -> new RoleException("Error: Admin Role is not found."));
					}

					roles.add(adminRole);

					break;
				default:
					Role userRole = null;

					if (roleService.findByName(ERole.ROLE_USER).isEmpty()) {
						userRole = new Role(ERole.ROLE_USER);
					} else {
						userRole = roleService.findByName(ERole.ROLE_USER)
								.orElseThrow(() -> new RoleException("Error: User Role is not found."));
					}

					roles.add(userRole);
				}
			});
		} else {
			roleService.findByName(ERole.ROLE_USER).ifPresentOrElse(roles::add,
					() -> roles.add(new Role(ERole.ROLE_USER)));
		}

		user.setRoles(roles);
		userService.saveUser(user);

		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}

	@PostMapping("/login")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
		String username = loginRequest.getUsername();
		String password = loginRequest.getPassword();

		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
				username, password);

		org.springframework.security.core.Authentication authentication = authenticationManager
				.authenticate(usernamePasswordAuthenticationToken);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		CustomUserDetails userDetails = (CustomUserDetails) authentication.getPrincipal();
		String jwt = jwtUtils.generateJwtToken(userDetails.getUsername());

		List<String> roles = userDetails.getAuthorities().stream().map(item -> item.getAuthority())
				.collect(Collectors.toList());

		RefreshToken refreshToken = refreshTokenService.createRefreshToken(userDetails.getId());

		JWTResponse jwtResponse = new JWTResponse();
		jwtResponse.setEmail(userDetails.getEmail());
		jwtResponse.setUsername(userDetails.getUsername());
		jwtResponse.setId(userDetails.getId());
		jwtResponse.setToken(jwt);
		jwtResponse.setRefreshToken(refreshToken.getToken());
		jwtResponse.setRoles(roles);

		return ResponseEntity.ok(jwtResponse);
	}

	@PostMapping("/refreshtoken")
	public ResponseEntity<?> refreshtoken(@Valid @RequestBody TokenRefreshRequest request) {

		String requestRefreshToken = request.getRefreshToken();

		RefreshToken token = refreshTokenService.findByToken(requestRefreshToken).orElseThrow(
				() -> new RefreshTokenException(requestRefreshToken + "Refresh token is not in database!"));

		RefreshToken deletedToken = refreshTokenService.verifyExpiration(token);

		User userRefreshToken = deletedToken.getUser();

		String newToken = jwtUtils.generateTokenFromUsername(userRefreshToken.getUsername());

		return ResponseEntity.ok(new TokenRefreshResponse(newToken, requestRefreshToken));
	}

	@GetMapping("/uid/{userId}")
	public ResponseEntity<?> getUserById(@PathVariable("userId") int userId) throws UserNotFoundException {
		// Optional<User> optional = userService.findById(userId);
		User optional = userService.findById(userId);
		if (optional != null) {
			return ResponseEntity.ok(optional);
		} else {
			throw new UserNotFoundException("User id is not valid");
		}
	}

	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<?> deleteUserById(@PathVariable("userId") int userId) throws UserNotFoundException {
		if (userService.deleteUserById(userId)) {
			return ResponseEntity.noContent().build();
		} else {
			throw new UserNotFoundException("User id is not valid");
		}
	}

	@PostMapping("/validateToken")
    public ResponseEntity<?> validateToken(@RequestBody String token) {
    	boolean valid = jwtUtils.validateJwtToken(token);

    	if(valid) {
    		return ResponseEntity.ok(valid);
    	}

    	else {
			return new ResponseEntity(false,HttpStatus.NOT_ACCEPTABLE);
		}
    	
    }

}
