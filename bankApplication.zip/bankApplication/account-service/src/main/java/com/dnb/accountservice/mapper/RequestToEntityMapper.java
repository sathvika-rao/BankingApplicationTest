package com.dnb.accountservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.payload.request.AccountRequest;


@Component //spring creates this class's object automatically
public class RequestToEntityMapper {
	//give request object and give back entity object
	public Account getAccountEntity(AccountRequest accountRequest) {
		Account account = new Account();
		account.setAadharNumber(accountRequest.getAadharNumber());
		account.setAccountType(accountRequest.getAccountType());
		account.setBalance(accountRequest.getBalance());
		account.setContactNumber(accountRequest.getContactNumber());
		account.setPanNumber(accountRequest.getPanNumber());
		account.setUserId(accountRequest.getUserId());
		return account;
	}
}
