package com.dnb.accountservice.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dnb.accountservice.dto.Account;



@Repository
//T is the entity type for the entity on which the operations need to be implemented, ID is type of primary key
public interface AccountRepository extends CrudRepository<Account, String>{
	
	public Optional<Account> findByUserId(Integer userId);

}
