package com.dnb.accountservice.dto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.Parameter;
import org.hibernate.validator.constraints.Length;

import com.dnb.accountservice.utils.AccountType;
import com.dnb.accountservice.utils.CustomAccountIdGenerator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode
@NoArgsConstructor
@ToString(exclude = "customer")
@Entity
public class Account {
	@Id 
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "account_seq") //if generator is specified, then it'll know to use its wrapper class
	@GenericGenerator(name = "account_seq", strategy = "com.dnb.accountservice.utils.CustomAccountIdGenerator",
	parameters = {@Parameter(name =CustomAccountIdGenerator.INCREMENT_PARAM, value = "50"),
			@Parameter(name=CustomAccountIdGenerator.VALUE_PREFIX_PARAMETER, value = "acc_"),
			@Parameter(name=CustomAccountIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d")
	})
	
	private String accountId;
	private Integer userId;
	private AccountType accountType;
	private String panNumber;
	private String aadharNumber;
	private String contactNumber;
	private boolean accountStatus = true;
	private int balance;
	
}
