package com.dnb.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.apache.http.HttpStatus;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.User;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientFundsException;
import com.dnb.accountservice.repo.AccountRepository;
import com.dnb.accountservice.utils.Amount;


@Service("accountServiceImpl")
public class AccountServiceImpl implements AccountService {
	
	@Autowired
	//@Qualifier("accountRepo2Impl")
	//AccountRepository accountRepository;
	AccountRepository accountRepository;
	
	@Autowired
	RestTemplate restTemplate;

	@Value("${api.auth}")
	private String URL;
	
	//using feign
//	@Autowired
//	APIClient apiClient;
	
	@Override
	public Account createAccount(Account account) throws IdNotFoundException
	{
		//Optional<Customer> customer = customerRepository.findById(account.getCustomer().getCustomerID());
		try {
		ResponseEntity<User> responseEntity = restTemplate.getForEntity(URL+"/uid/"+account.getUserId(), User.class);
		//ResponseEntity<Customer> responseEntity = apiClient.getCustomerById(account.getCustomerID());	
			return accountRepository.save(account);
		}
		catch(Exception e) {
			 throw new IdNotFoundException(e.getMessage());
		}
	}

	@Override
	public Optional<Account> getAccountById(String accountId){
		// TODO Auto-generated method stub
		return accountRepository.findById(accountId);
	}

	@Override
	public boolean deleteAccountById(String accountId) {
		// TODO Auto-generated method stub
		if(accountRepository.existsById(accountId)) {
			accountRepository.deleteById(accountId);
			return true;
		}
		else 
			//throw new IdNotFoundException("ID not found");
			return false;
	}

	@Override
	public List<Account> getAllAccounts(){
		// TODO Auto-generated method stub
		return (List<Account>) accountRepository.findAll();
	}

	@Override
	//test by giving wrong account id
	public Account depositMoney(String accountId, Amount amount) throws IdNotFoundException {
		// TODO Auto-generated method stub
		Account account = accountRepository.findById(accountId).get();
		if(account!=null) {
			account.setBalance(account.getBalance()+amount.getAmount());
			return account;
		}
		else {
			throw new IdNotFoundException("Account does not exist");
		}
	}

	@Override
	public Account withdrawMoney(String accountId, Amount amount) throws InsufficientFundsException, IdNotFoundException {
		// TODO Auto-generated method stub
		Account account = accountRepository.findById(accountId).get();
		if(account!=null) {
			account.setBalance(account.getBalance()-amount.getAmount());
			if(account.getBalance()<10000) {
				throw new InsufficientFundsException("Insufficient Funds - Minimum balance should be 10000");
			}
			return account;
		}
		else {
			throw new IdNotFoundException("Account does not exist");
		}
	}

	@Override
	public Account suspendAccount() {
		// TODO Auto-generated method stub
		List<Account> accounts = (List<Account>) accountRepository.findAll();
		accounts.forEach(
			acc -> acc.setAccountStatus(false)	
		);
		return null;
	}

	public Optional<Account> getAccountByUserId(Integer userId) {

		return accountRepository.findByUserId(userId);

	}

}
