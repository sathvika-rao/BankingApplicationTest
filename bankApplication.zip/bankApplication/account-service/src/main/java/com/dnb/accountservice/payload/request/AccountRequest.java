package com.dnb.accountservice.payload.request;

import java.time.LocalDate;

import org.hibernate.validator.constraints.Length;

import com.dnb.accountservice.utils.AccountType;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AccountRequest {
	@NotNull(message = "User id should not be blank should not be blank")
	private Integer userId;
	@Enumerated(EnumType.STRING)
	private AccountType accountType;
	private String panNumber;
	private String aadharNumber;
	@Length(min = 10, max =10)
	@jakarta.validation.constraints.Pattern(regexp = "^[0-9]{10}$")
	private String contactNumber;
	@Min(value = 10000, message = "Minimum balance should be 10000")
	private int balance;
}
