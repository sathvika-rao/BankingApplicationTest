package com.dnb.accountservice.utils;

import lombok.Data;

@Data
public class Amount {
	int amount;
}
