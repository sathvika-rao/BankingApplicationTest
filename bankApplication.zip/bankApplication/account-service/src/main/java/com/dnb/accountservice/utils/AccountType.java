package com.dnb.accountservice.utils;

public enum AccountType {
	SAVING,
	CURRENT
}
