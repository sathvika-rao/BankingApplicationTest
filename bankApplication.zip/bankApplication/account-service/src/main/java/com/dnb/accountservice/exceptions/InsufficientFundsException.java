package com.dnb.accountservice.exceptions;

public class InsufficientFundsException extends Exception{
	
	public InsufficientFundsException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	
	public String toString() {
		return super.toString()+super.getMessage();
	}
	
}
