package com.dnb.accountservice.dto;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
