import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient: HttpClient) { }

  endpoint: string = '/api/account';

  createAccount(account: any): Observable<any> {
    return this.httpClient.post(this.endpoint+'/create', account);
  }

  deleteAccount(accountId: String): Observable<any> {
    return this.httpClient.delete(this.endpoint+'/delete/'+accountId);
  }

  getAccountByUserId(userId: String): Observable<any> {
    return this.httpClient.get(this.endpoint+'/getAccountByUserId/'+userId);
  }

  withdrawMoney(accountId: String, amount: any): Observable<any> {
    return this.httpClient.put(this.endpoint+'/withdrawal/'+accountId, amount);   
  }

  depositMoney(accountId: String, amount: any): Observable<any> {
    return this.httpClient.put(this.endpoint+'/deposit/'+accountId, amount);
  }

  suspendAccount(accountId:String, account: any): Observable<any> {
    return this.httpClient.put(this.endpoint+'/suspend/'+accountId,account);
  }
}
