import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account-routing.module';
import { CreateAccountComponent } from './components/account-form/create-account/create-account.component';
import { DepositComponent } from './components/account-form/deposit/deposit.component';
import { WithdrawComponent } from './components/account-form/withdraw/withdraw.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AccountService } from './services/account.service';
import { httpInterceptors } from '../shared/interceptors';


@NgModule({
  declarations: [
    CreateAccountComponent,
    DepositComponent,
    WithdrawComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    AccountRoutingModule
  ],
  providers: [AccountService, httpInterceptors]
})
export class AccountModule { }
