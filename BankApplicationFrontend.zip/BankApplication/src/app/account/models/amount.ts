export interface Amount {
    amount: number;
}
