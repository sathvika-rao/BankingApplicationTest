export interface IAccount {
    userId : number,
    accountType : string,
    panNumber : string,
    aadharNumber : string,
    contactNumber  :  string ,
    balance  : number
}
