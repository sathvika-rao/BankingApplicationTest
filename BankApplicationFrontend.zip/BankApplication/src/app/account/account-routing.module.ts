import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateAccountComponent } from './components/account-form/create-account/create-account.component';
import { DepositComponent } from './components/account-form/deposit/deposit.component';
import { WithdrawComponent } from './components/account-form/withdraw/withdraw.component';

const routes: Routes = [
  {path: 'create-account', component: CreateAccountComponent},
  {path: 'deposit', component: DepositComponent},
  {path: 'withdraw', component: WithdrawComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
