import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Amount } from 'src/app/account/models/amount';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  constructor(private accountService: AccountService, private router: Router) { }
  accountDetails: any ={};
  amount: Amount = {
    amount: 0
  }

  depositMoney() {
    let accountId = JSON.parse(localStorage.getItem("accountDetails")||'').accountId;
    console.log(this.amount);
    this.accountService.depositMoney(accountId, this.amount).subscribe(
      (res) => {
        console.log(res);
        localStorage.setItem('accountDetails', JSON.stringify(res));
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  ngOnInit(): void {
  }

}
