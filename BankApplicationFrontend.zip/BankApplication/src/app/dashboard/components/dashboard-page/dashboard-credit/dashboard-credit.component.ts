import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-credit',
  templateUrl: './dashboard-credit.component.html',
  styleUrls: ['./dashboard-credit.component.css']
})
export class DashboardCreditComponent implements OnInit {
  @Input() 
  creditDetails: [] =[]
  flag: boolean = true;
  length: number = this.creditDetails.length;
  constructor() { }

  ngOnInit(): void {
    if(this.length>0) {
      this.flag = true;
    }
    else if(this.length=0) {
      this.flag = false;
    }

  }

}
