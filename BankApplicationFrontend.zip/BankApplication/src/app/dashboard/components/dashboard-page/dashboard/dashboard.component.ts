import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/account/services/account.service';
import { CreditService } from 'src/app/credit/services/credit.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  flag: boolean = false;
  constructor(
    private accountService: AccountService,
    private creditService: CreditService
  ) {}

  userDetails: any = {};
  account: any = {};
  balance: number;
  accountDetails: any = {};
  creditDetails: any = {};

  ngOnInit(): void {
    this.userDetails = JSON.parse(localStorage.getItem('userDetails') || '');

    console.log(this.userDetails.id);

    this.accountService.getAccountByUserId(this.userDetails.id).subscribe(
      (res) => {
        console.log(res);
        this.account = res;
        this.creditService.getAllCreditsByUserId(this.userDetails.id).subscribe(
          (res) => {
            console.log(res);
            this.creditDetails = res;
          },
          (err) => {
            console.log(err);
          }
        );
      },
      (err) => {
        console.log(err);
        if (err.status == 404) {
          this.flag = true;
        }
      }
    );
  }

  showBalance() {
    this.accountDetails = JSON.parse(localStorage.getItem('accountDetails') || '');
    this.balance = this.accountDetails.balance;
  }
}
