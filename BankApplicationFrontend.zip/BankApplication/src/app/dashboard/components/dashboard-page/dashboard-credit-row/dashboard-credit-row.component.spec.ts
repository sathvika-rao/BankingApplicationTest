import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardCreditRowComponent } from './dashboard-credit-row.component';

describe('DashboardCreditRowComponent', () => {
  let component: DashboardCreditRowComponent;
  let fixture: ComponentFixture<DashboardCreditRowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardCreditRowComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DashboardCreditRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
