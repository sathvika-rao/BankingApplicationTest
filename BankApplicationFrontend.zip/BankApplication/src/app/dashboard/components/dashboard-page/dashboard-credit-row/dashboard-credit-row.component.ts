import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-credit-row',
  templateUrl: './dashboard-credit-row.component.html',
  styleUrls: ['./dashboard-credit-row.component.css']
})
export class DashboardCreditRowComponent implements OnInit {
  @Input() c: any = {};
  constructor() { }

  ngOnInit(): void {
  }

}
