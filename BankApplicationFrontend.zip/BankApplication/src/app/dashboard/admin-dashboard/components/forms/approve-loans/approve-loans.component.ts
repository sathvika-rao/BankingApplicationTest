import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ICredit } from 'src/app/credit/models/icredit';
import { CreditService } from 'src/app/credit/services/credit.service';

@Component({
  selector: 'app-approve-loans',
  templateUrl: './approve-loans.component.html',
  styleUrls: ['./approve-loans.component.css']
})
export class ApproveLoansComponent implements OnInit {

  constructor(private creditService: CreditService, private router: Router) { }

  credit: ICredit = {
    creditType: '',
    userId: 0
  }

  createCredit() {
    let userId = JSON.parse(localStorage.getItem("userDetails")||'').id;
    this.credit.userId=userId;
    console.log(this.credit)
    this.creditService.approveCreditStatusByUserId(JSON.parse(localStorage.getItem("creditDetails")||'').creditId).subscribe(
      (res) => {
        console.log(res);
        this.router.navigate(['/dashboard']);
        // localStorage.setItem("accountDetails", JSON.stringify(res));
      },
      (err) => {
        console.log(err);
      }
    );
  }

  ngOnInit(): void {
  }

}
