import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IAccount } from 'src/app/account/models/iaccount';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-close-account',
  templateUrl: './close-account.component.html',
  styleUrls: ['./close-account.component.css'],
})
export class CloseAccountComponent implements OnInit {
  accountId: string = '';
  error: string = '';
  constructor(private accountService: AccountService, private router: Router) {}

  account: IAccount = {
    userId: 0,
    accountType: '',
    panNumber: '',
    aadharNumber: '',
    contactNumber: '',
    balance: 0
  }


  ngOnInit(): void {}

  closeAccount() {
    this.accountService.suspendAccount(this.accountId, this.account).subscribe(
      (res) => {
        console.log(res);
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }
}

