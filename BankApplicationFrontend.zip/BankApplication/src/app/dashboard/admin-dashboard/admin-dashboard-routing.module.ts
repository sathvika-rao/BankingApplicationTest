import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApproveLoansComponent } from './components/forms/approve-loans/approve-loans.component';
import { CloseAccountComponent } from './components/forms/close-account/close-account.component';
import { AuthGuard } from 'src/app/shared/guards/auth.guard';

const routes: Routes = [
  {path: 'approve-loans', component:ApproveLoansComponent,
  canActivate: [AuthGuard],},
  {path: 'close-account', component:CloseAccountComponent, canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminDashboardRoutingModule { }
