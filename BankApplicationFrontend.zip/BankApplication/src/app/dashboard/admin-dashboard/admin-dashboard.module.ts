import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminDashboardRoutingModule } from './admin-dashboard-routing.module';
import { ApproveLoansComponent } from './components/forms/approve-loans/approve-loans.component';
import { CloseAccountComponent } from './components/forms/close-account/close-account.component';
import { CreditService } from 'src/app/credit/services/credit.service';
import { AccountService } from 'src/app/account/services/account.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    ApproveLoansComponent,
    CloseAccountComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    AdminDashboardRoutingModule
  ],
  providers : [AccountService, CreditService]
})
export class AdminDashboardModule { }
