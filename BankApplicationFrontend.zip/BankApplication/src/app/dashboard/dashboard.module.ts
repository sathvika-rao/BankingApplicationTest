import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard-page/dashboard/dashboard.component';
import { DashboardActionComponent } from './components/dashboard-page/dashboard-action/dashboard-action.component';
import { DashboardCreditComponent } from './components/dashboard-page/dashboard-credit/dashboard-credit.component';
import { DashboardCreditRowComponent } from './components/dashboard-page/dashboard-credit-row/dashboard-credit-row.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AccountService } from '../account/services/account.service';
import { CreditService } from '../credit/services/credit.service';
import { httpInterceptors } from '../shared/interceptors';


@NgModule({
  declarations: [
    DashboardComponent,
    DashboardActionComponent,
    DashboardCreditComponent,
    DashboardCreditRowComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    DashboardRoutingModule
  ],
  providers: [AccountService, CreditService, httpInterceptors]
})
export class DashboardModule { }
