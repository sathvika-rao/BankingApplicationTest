import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreditRoutingModule } from './credit-routing.module';
import { CreateCreditComponent } from './components/credit-form/create-credit/create-credit.component';
import { CreditService } from './services/credit.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AccountService } from '../account/services/account.service';
import { httpInterceptors } from '../shared/interceptors';


@NgModule({
  declarations: [
    CreateCreditComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    CreditRoutingModule
  ],
  providers: [CreditService, AccountService, httpInterceptors]
})
export class CreditModule { }
