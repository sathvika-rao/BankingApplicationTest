export interface ICredit {
	creditType :  string ,
     userId  : number
}
