import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CreditService {

  constructor(private httpClient: HttpClient) { }

  endpoint: string = 'api/credit';

  createCredit(credit: any): Observable<any> {
    return this.httpClient.post(this.endpoint+'/create', credit);
  }

  getAllCredits(): Observable<any> {
    return this.httpClient.get(this.endpoint+'/allCredits');
  }

  getAllCreditsByUserId(userId: number): Observable<any> {
    return this.httpClient.get(this.endpoint+'/allCreditsByUserId/'+userId);
  }

  approveCreditStatusByUserId(creditId: string): Observable<any> {
    return this.httpClient.get(this.endpoint+'/approveCreditStatus/'+creditId);
  }

}
