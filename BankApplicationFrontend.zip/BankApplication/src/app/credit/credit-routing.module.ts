import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateCreditComponent } from './components/credit-form/create-credit/create-credit.component';

const routes: Routes = [
  {path: 'create-credit', component:CreateCreditComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreditRoutingModule { }
