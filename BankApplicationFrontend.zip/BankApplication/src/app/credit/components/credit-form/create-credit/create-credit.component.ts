import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from 'src/app/account/services/account.service';
import { ICredit } from 'src/app/credit/models/icredit';
import { CreditService } from 'src/app/credit/services/credit.service';

@Component({
  selector: 'app-create-credit',
  templateUrl: './create-credit.component.html',
  styleUrls: ['./create-credit.component.css']
})
export class CreateCreditComponent implements OnInit {

  constructor(private creditService: CreditService, private router: Router) { }

  credit: ICredit = {
    creditType: '',
    userId: 0
  }

  createCredit() {
    let userId = JSON.parse(localStorage.getItem("userDetails")||'').id;
    this.credit.userId=userId;
    console.log(this.credit)
    this.creditService.createCredit(this.credit).subscribe(
      (res) => {
        console.log(res);
        this.router.navigate(['/dashboard']);
        localStorage.setItem("creditDetails", JSON.stringify(res));
      },
      (err) => {
        console.log(err);
      }
    );
  }

  ngOnInit(): void {
  }
}
